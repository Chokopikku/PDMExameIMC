package com.pdm.myapplication.data

class ImcRepository(private val imcDao: ImcDao) {

    suspend fun addImc(imc: Imc) {
        imcDao.addImc(imc)
    }
}