package com.pdm.myapplication

// All code developed by: Fábio Pereira (21805862)
// Question 1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import com.pdm.myapplication.data.Imc
import com.pdm.myapplication.data.ImcViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var name: String
    private lateinit var imcViewModel: ImcViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calcButton = findViewById<TextView>(R.id.calcButton)
        calcButton.setOnClickListener { calc() }

        // Question 2, part c.
        val extras = intent.extras
        if (extras != null) name = extras.getString("name").toString()
    }

    // Question 1, part c.
    fun calc() {
        val heightText: String = findViewById<EditText>(R.id.heightInput).text.toString()
        val weightText: String = findViewById<EditText>(R.id.weightInput).text.toString()
        val resultText = findViewById<TextView>(R.id.resultText)

        if (heightText.isEmpty() || heightText == "" || weightText.isEmpty() || weightText == "") {
            val alertBuilder = AlertDialog.Builder(this)
            alertBuilder.setMessage("Inserir ambos os valores.")
            val alert = alertBuilder.create()
            alert.setTitle("Atenção!")
            alert.show()

            Log.d("AppExame", "Não foram inseridos ambos os valores")
        } else {
            var height = heightText.toDouble()
            if (findViewById<RadioButton>(R.id.unitCm).isChecked) {
                height = height/100
            } else if (findViewById<RadioButton>(R.id.unitDm).isChecked) {
                height = height/10
            }
            var weight = weightText.toDouble()
            if (findViewById<RadioButton>(R.id.unitG).isChecked) {
                weight = weight/1000
            }

            Log.d("AppExame", "A calcular IMC: $weight Kg & $height m")
            val imc: Double = weight / (height * height)
            Toast.makeText(applicationContext, "IMC $imc", Toast.LENGTH_SHORT).show()

            var resultString: String
            when {
                imc < 18.75 -> resultString = getString(R.string.abaixo)
                imc < 25 -> resultString = getString(R.string.normal)
                imc < 45 -> resultString = getString(R.string.acima)
                else -> resultString = getString(R.string.obesidade)
            }
            resultText.text = resultString

            imcViewModel = ViewModelProvider(this).get(ImcViewModel::class.java)
            imcViewModel.addImc(Imc(0, name, imc, resultString))
        }
    }
}
