package com.pdm.myapplication.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(version = 1, exportSchema = false, entities = [Imc::class])
abstract class ImcDatabase: RoomDatabase() {
    abstract fun imcDao(): ImcDao

    companion object {
        @Volatile
        private var INSTANCE: ImcDatabase? = null

        fun getDatabase(context: Context): ImcDatabase {
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ImcDatabase::class.java,
                    "Projeto"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}