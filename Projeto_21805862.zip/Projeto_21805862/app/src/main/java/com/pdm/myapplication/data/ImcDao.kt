package com.pdm.myapplication.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy

@Dao
interface ImcDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addImc(imc: Imc)
}