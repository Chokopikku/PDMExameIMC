package com.pdm.myapplication.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Imc")
data class Imc(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val name: String,
    val imc: Double,
    val situation: String
)
