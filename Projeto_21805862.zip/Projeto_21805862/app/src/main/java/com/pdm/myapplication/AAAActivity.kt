package com.pdm.myapplication

// All code developed by: Fábio Pereira (21805862)
// Question 2

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AAAActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aaa)

        val calcButton = findViewById<TextView>(R.id.calcButton2)
        calcButton.setOnClickListener { goMain() }
    }

    // Question 2, part c.
    fun goMain() {
        val name = findViewById<EditText>(R.id.nameInput).text.toString()
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("name", name)
        startActivity(intent)
        finish()
    }
}