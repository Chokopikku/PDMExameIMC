package com.pdm.myapplication.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ImcViewModel(application: Application): AndroidViewModel(application) {
    val repository: ImcRepository

    init {
        val imcDao = ImcDatabase.getDatabase(application).imcDao()
        repository = ImcRepository(imcDao)
    }

    fun addImc(imc: Imc) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addImc(imc)
        }
    }
}